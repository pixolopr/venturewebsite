<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 
 class Photo_model extends PIXOLO_Model 
 { 

 
 	 //Write functions here 
 } 
 
 ?>