<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 
 class Eventtag_model extends PIXOLO_Model 
 { 
	 public $_table = 'eventtag';  
 
 	 //Write functions here 
 } 
 
 ?>