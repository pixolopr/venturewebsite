<?php 
 defined('BASEPATH') OR exit('No direct script access allowed'); 
 
 class Acces_model extends PIXOLO_Model 
 { 

 public $_table = 'access';
 	 //Write functions here 
 } 
 
 ?>