var navigationservice = angular.module('navigationservice', [])

.factory('NavigationService', function () {
    

    return {
        

    }
});