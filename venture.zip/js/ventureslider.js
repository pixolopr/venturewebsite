$(document).ready(
    function () {
        console.log("HEY ITS WORKING");
        /*
        boatdiv
startupsigndiv
islanddiv
(selector).animate({styles},speed,easing,callback)
*/

    });
